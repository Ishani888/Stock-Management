﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_management
{
    public partial class Category : Form
    {
        public Category()
        {
            InitializeComponent();
            ShowCategory();
            CountCat();
        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void ShowCategory()
        {
            con.Open();
            string Query = "SELECT * from [category]";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            CategoryDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        

       
       
        private void CountCat() {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT count(*) from [category]",con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            CountLable.Text = dt.Rows[0][0].ToString();
            con.Close();
        }
        
        int key = 0;

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (CategoryName.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into [category] values (@CategoryName)", con);
                    cmd.Parameters.AddWithValue("@CategoryName", CategoryName.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "category saved!!!");
                    con.Close();
                    ShowCategory();
                    CountCat();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (CategoryName.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE  [category] set [Category Name]=@CategoryName WHERE [Category Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@CategoryName", CategoryName.Text);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "category update!!!");
                    con.Close();
                    ShowCategory();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show(this, "Select the Category!!!");
            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  [category] WHERE [Category Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Category Deleted!!!");
                    con.Close();
                    ShowCategory();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CategoryName_Enter(object sender, EventArgs e)
        {
   
                if (CategoryName.Text == "Category Name")
                {
                    CategoryName.Text = "";
                    CategoryName.ForeColor = Color.Black;
                }
          
        }

        private void CategoryName_Leave(object sender, EventArgs e)
        {
        if (CategoryName.Text == "")
        {
            CategoryName.Text = "Category Name";
            CategoryName.ForeColor = Color.LightGray;
        }
    }

        private void CategoryDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.CategoryDGV.Rows[e.RowIndex];
                CategoryName.Text = row.Cells[1].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void Category_Load(object sender, EventArgs e)
        {
            CategoryDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
