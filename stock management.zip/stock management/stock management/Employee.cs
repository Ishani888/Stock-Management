﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_management

{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
            ShowEmployee();
        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void ShowEmployee()
        {
            con.Open();
            string Query = "SELECT * from employee";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            EmployeeDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        //adding textbox placeholders
        private void FirstName_Enter(object sender, EventArgs e)
        {
            if (FirstName.Text == "First Name")
            {
                FirstName.Text = "";
                FirstName.ForeColor = Color.Black;
            }
        }

        private void FirstName_Leave(object sender, EventArgs e)
        {
            if (FirstName.Text == "")
            {
                FirstName.Text = "First Name";
                FirstName.ForeColor = Color.LightGray;
            }
        }

        private void LastName_Enter(object sender, EventArgs e)
        {
            if (LastName.Text == "Last Name")
            {
                LastName.Text = "";
                LastName.ForeColor = Color.Black;
            }
        }

        private void LastName_Leave(object sender, EventArgs e)
        {
            if (LastName.Text == "")
            {
                LastName.Text = "Last Name";
                LastName.ForeColor = Color.LightGray;
            }
        }

        private void ContactNo_Enter(object sender, EventArgs e)
        {
            if (ContactNo.Text == "Contact No")
            {
                ContactNo.Text = "";
                ContactNo.ForeColor = Color.Black;
            }
        }

        private void ContactNo_Leave(object sender, EventArgs e)
        {
            if (ContactNo.Text == "")
            {
                ContactNo.Text = "Contact No";
                ContactNo.ForeColor = Color.LightGray;
            }
        }

        private void Birth_Enter(object sender, EventArgs e)
        {
            if (Birth.Text == "Date of Birth")
            {
                Birth.Text = "";
                Birth.ForeColor = Color.Black;
            }
        }

        private void Birth_Leave(object sender, EventArgs e)
        {
            if (Birth.Text == "")
            {
                Birth.Text = "Date of Birth";
                Birth.ForeColor = Color.LightGray;
            }
        }
       
        private void Save_Click(object sender, EventArgs e)
        {
            if (FirstName.Text == "" || LastName.Text == "" || ContactNo.Text == "" || Birth.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT into employee values (@FirstName,@LastName,@ContactNo,@DateOfBirth)", con);
                    cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", LastName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ContactNo.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", Birth.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Employee saved!!!");
                    con.Close();
                    ShowEmployee();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }
        int key = 0;
        private void Edit_Click(object sender, EventArgs e)
        {
            if (FirstName.Text == "" || LastName.Text == "" || ContactNo.Text == "" || Birth.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE  employee SET  [First Name]=@FirstName,[Last Name]=@LastName,[Contact No]=@ContactNo,[Date Of Birth]=@DateOfBirth WHERE [Employee Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
                    cmd.Parameters.AddWithValue("@LastName", LastName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ContactNo.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", Birth.Text);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Employee Update!!!");
                    con.Close();
                    ShowEmployee();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (FirstName.Text == "" ||  LastName.Text == "" || ContactNo.Text == "" || Birth.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  employee WHERE [Employee Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Employee Update!!!");
                    con.Close();
                    ShowEmployee();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }

        private void EmployeeDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.EmployeeDGV.Rows[e.RowIndex];
                FirstName.Text = row.Cells[1].Value.ToString();
                LastName.Text = row.Cells[2].Value.ToString();
                ContactNo.Text = row.Cells[3].Value.ToString();
                Birth.Text = row.Cells[4].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            EmployeeDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);
        }
    }
}
