﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace sales_management
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            ShowCustomer();
        }
        private void ShowCustomer() {
            con.Open();
            string Query = "SELECT * from Customer";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            CustomerDGV.DataSource = ds.Tables[0];
            con.Close();

        }
       
        
        private void Customer_Load(object sender, EventArgs e)
        {
           CustomerDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);

        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void Save_Click(object sender, EventArgs e)
        {
            if ( custoName.Text == "" || ConNo.Text == "" || gender.SelectedIndex == -1 || Address.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into Customer values (@Name,@ContactNo,@Gender,@Address)",con);
                    cmd.Parameters.AddWithValue("@Name", custoName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ConNo.Text);
                    cmd.Parameters.AddWithValue("@Gender", gender.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Address", Address.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Customer saved!!!");
                    con.Close();
                    ShowCustomer();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
       
        private void Edit_Click(object sender, EventArgs e)
        {
            if (custoName.Text == "" || ConNo.Text == "" || gender.SelectedIndex == -1 || Address.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE  Customer SET  Name=@Name,[Contact No]=@ContactNo,Gender=@Gender,Address=@Address WHERE [Customer Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@Name", custoName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ConNo.Text);
                    cmd.Parameters.AddWithValue("@Gender", gender.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Address", Address.Text);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Customer Update!!!");
                    con.Close();
                    ShowCustomer();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        

        private void gender_Enter(object sender, EventArgs e)
        {
            if (gender.Text == "gender")
            {
                gender.Text = "";
                gender.ForeColor = Color.Black;
            }
        }

        private void gender_Leave(object sender, EventArgs e)
        {
            if (gender.Text == "")
            {
                gender.Text = "gender";
                gender.ForeColor = Color.LightGray;
            }
        }

        private void Address_Enter(object sender, EventArgs e)
        {
            if (Address.Text == "Address")
            {
                Address.Text = "";
                Address.ForeColor = Color.Black;
            }
        }

        private void Address_Leave(object sender, EventArgs e)
        {
            if (Address.Text == "")
            {
                Address.Text = "Address";
                Address.ForeColor = Color.LightGray;
            }
        }
        int key = 0;

        private void Delete_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show(this, "Select the customer!!!");
            }
            else {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  Customer WHERE [Customer Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Customer Deleted!!!");
                    con.Close();
                    ShowCustomer();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();

        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void custoName_Enter_1(object sender, EventArgs e)
        {
            if (custoName.Text == "Customer Name")
            {
                custoName.Text = "";
                custoName.ForeColor = Color.Black;
            }
        }

        private void custoName_Leave_1(object sender, EventArgs e)
        {
            if (custoName.Text == "")
            {
                custoName.Text = "Customer Name";
                custoName.ForeColor = Color.LightGray;
            }
        }

        

        private void ConNo_Enter_1(object sender, EventArgs e)
        {
            if (ConNo.Text == "Customer Name")
            {
                ConNo.Text = "";
                ConNo.ForeColor = Color.Black;
            }
        }

        private void ConNo_Leave_1(object sender, EventArgs e)
        {
            if (ConNo.Text == "")
            {
                ConNo.Text = "Customer Name";
                ConNo.ForeColor = Color.LightGray;
            }
        }

        private void CustomerDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.CustomerDGV.Rows[e.RowIndex];
                custoName.Text = row.Cells[1].Value.ToString();
                ConNo.Text = row.Cells[2].Value.ToString();
                gender.Text = row.Cells[3].Value.ToString();
                Address.Text = row.Cells[4].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }
    }
}
