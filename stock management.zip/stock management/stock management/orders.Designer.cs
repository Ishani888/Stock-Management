﻿namespace sales_management
{
    partial class orders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orders));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.OrderDGV = new System.Windows.Forms.DataGridView();
            this.Amount = new System.Windows.Forms.TextBox();
            this.BillBtn = new System.Windows.Forms.Button();
            this.OrderBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.OrderDate = new System.Windows.Forms.DateTimePicker();
            this.ItemId = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CustomerID = new System.Windows.Forms.ComboBox();
            this.ItemName = new System.Windows.Forms.TextBox();
            this.BillDGV = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.TextBox();
            this.ItemPrice = new System.Windows.Forms.TextBox();
            this.TotalPri = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.SupplierBtn = new System.Windows.Forms.Button();
            this.CategoryBtn = new System.Windows.Forms.Button();
            this.ItemBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.CustomerBtn = new System.Windows.Forms.Button();
            this.EmployeeBtn = new System.Windows.Forms.Button();
            this.DashboardBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PerchaceMethod = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.OrderDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillDGV)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Martina", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(115, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 20);
            this.label2.TabIndex = 40;
            this.label2.Text = "Manage Orders";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.AliceBlue;
            this.label1.Location = new System.Drawing.Point(38, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 25);
            this.label1.TabIndex = 38;
            this.label1.Text = "Sales Management System";
            // 
            // OrderDGV
            // 
            this.OrderDGV.AllowUserToAddRows = false;
            this.OrderDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.OrderDGV.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.OrderDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.OrderDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OrderDGV.DefaultCellStyle = dataGridViewCellStyle14;
            this.OrderDGV.Location = new System.Drawing.Point(342, 90);
            this.OrderDGV.Name = "OrderDGV";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.OrderDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft MHei", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
            this.OrderDGV.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.OrderDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.OrderDGV.Size = new System.Drawing.Size(871, 272);
            this.OrderDGV.TabIndex = 35;
            this.OrderDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.OrderDGV_CellClick);
            // 
            // Amount
            // 
            this.Amount.Enabled = false;
            this.Amount.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.Amount.Location = new System.Drawing.Point(77, 217);
            this.Amount.Multiline = true;
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(215, 34);
            this.Amount.TabIndex = 32;
            this.Amount.WordWrap = false;
            this.Amount.Enter += new System.EventHandler(this.Amount_Enter);
            this.Amount.Leave += new System.EventHandler(this.Amount_Leave);
            // 
            // BillBtn
            // 
            this.BillBtn.BackColor = System.Drawing.Color.White;
            this.BillBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.BillBtn.Location = new System.Drawing.Point(143, 649);
            this.BillBtn.Name = "BillBtn";
            this.BillBtn.Size = new System.Drawing.Size(75, 23);
            this.BillBtn.TabIndex = 43;
            this.BillBtn.Text = "Add to Bill";
            this.BillBtn.UseVisualStyleBackColor = false;
            this.BillBtn.Click += new System.EventHandler(this.BillBtn_Click);
            // 
            // OrderBtn
            // 
            this.OrderBtn.BackColor = System.Drawing.Color.White;
            this.OrderBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.OrderBtn.Location = new System.Drawing.Point(77, 339);
            this.OrderBtn.Name = "OrderBtn";
            this.OrderBtn.Size = new System.Drawing.Size(75, 23);
            this.OrderBtn.TabIndex = 42;
            this.OrderBtn.Text = "Order Now";
            this.OrderBtn.UseVisualStyleBackColor = false;
            this.OrderBtn.Click += new System.EventHandler(this.OrderBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.BackColor = System.Drawing.Color.White;
            this.CancelBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.CancelBtn.Location = new System.Drawing.Point(202, 339);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 41;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = false;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // OrderDate
            // 
            this.OrderDate.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.OrderDate.Location = new System.Drawing.Point(77, 167);
            this.OrderDate.Name = "OrderDate";
            this.OrderDate.Size = new System.Drawing.Size(215, 25);
            this.OrderDate.TabIndex = 46;
            this.OrderDate.Value = new System.DateTime(2023, 12, 4, 0, 0, 0, 0);
            // 
            // ItemId
            // 
            this.ItemId.Cursor = System.Windows.Forms.Cursors.Default;
            this.ItemId.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.ItemId.FormattingEnabled = true;
            this.ItemId.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ItemId.Location = new System.Drawing.Point(77, 433);
            this.ItemId.Name = "ItemId";
            this.ItemId.Size = new System.Drawing.Size(200, 25);
            this.ItemId.TabIndex = 48;
            this.ItemId.SelectionChangeCommitted += new System.EventHandler(this.ItemId_SelectionChangeCommitted);
            this.ItemId.Enter += new System.EventHandler(this.ItemId_Enter);
            this.ItemId.Leave += new System.EventHandler(this.ItemId_Leave);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Location = new System.Drawing.Point(341, 375);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 5);
            this.panel1.TabIndex = 50;
            // 
            // CustomerID
            // 
            this.CustomerID.Cursor = System.Windows.Forms.Cursors.Default;
            this.CustomerID.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.CustomerID.FormattingEnabled = true;
            this.CustomerID.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.CustomerID.Location = new System.Drawing.Point(77, 124);
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.Size = new System.Drawing.Size(215, 25);
            this.CustomerID.TabIndex = 51;
            this.CustomerID.Enter += new System.EventHandler(this.CustomerID_Enter);
            this.CustomerID.Leave += new System.EventHandler(this.CustomerID_Leave);
            // 
            // ItemName
            // 
            this.ItemName.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.ItemName.Location = new System.Drawing.Point(77, 478);
            this.ItemName.Multiline = true;
            this.ItemName.Name = "ItemName";
            this.ItemName.Size = new System.Drawing.Size(200, 34);
            this.ItemName.TabIndex = 52;
            this.ItemName.WordWrap = false;
            this.ItemName.Enter += new System.EventHandler(this.ItemName_Enter);
            this.ItemName.Leave += new System.EventHandler(this.ItemName_Leave);
            // 
            // BillDGV
            // 
            this.BillDGV.AllowUserToAddRows = false;
            this.BillDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BillDGV.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BillDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.BillDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BillDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ProName,
            this.Price,
            this.quantity1,
            this.TotalPrice});
            this.BillDGV.Location = new System.Drawing.Point(342, 391);
            this.BillDGV.Name = "BillDGV";
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.MediumVioletRed;
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.LightPink;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            this.BillDGV.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.BillDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BillDGV.Size = new System.Drawing.Size(871, 303);
            this.BillDGV.TabIndex = 54;
            this.BillDGV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BillDGV_CellClick);
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            // 
            // ProName
            // 
            this.ProName.HeaderText = "Product Name";
            this.ProName.Name = "ProName";
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            // 
            // quantity1
            // 
            this.quantity1.HeaderText = "Quantity";
            this.quantity1.Name = "quantity1";
            // 
            // TotalPrice
            // 
            this.TotalPrice.HeaderText = "Total Price";
            this.TotalPrice.Name = "TotalPrice";
            // 
            // Quantity
            // 
            this.Quantity.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.Quantity.Location = new System.Drawing.Point(77, 586);
            this.Quantity.Multiline = true;
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(200, 34);
            this.Quantity.TabIndex = 55;
            this.Quantity.Enter += new System.EventHandler(this.Quantity_Enter);
            this.Quantity.Leave += new System.EventHandler(this.Quantity_Leave);
            // 
            // ItemPrice
            // 
            this.ItemPrice.Font = new System.Drawing.Font("Microsoft MHei", 9.75F, System.Drawing.FontStyle.Bold);
            this.ItemPrice.Location = new System.Drawing.Point(77, 537);
            this.ItemPrice.Multiline = true;
            this.ItemPrice.Name = "ItemPrice";
            this.ItemPrice.Size = new System.Drawing.Size(200, 34);
            this.ItemPrice.TabIndex = 56;
            this.ItemPrice.Enter += new System.EventHandler(this.ItemPrice_Enter);
            this.ItemPrice.Leave += new System.EventHandler(this.ItemPrice_Leave);
            // 
            // TotalPri
            // 
            this.TotalPri.AutoSize = true;
            this.TotalPri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(79)))));
            this.TotalPri.ForeColor = System.Drawing.Color.Red;
            this.TotalPri.Location = new System.Drawing.Point(237, 681);
            this.TotalPri.Name = "TotalPri";
            this.TotalPri.Size = new System.Drawing.Size(0, 13);
            this.TotalPri.TabIndex = 57;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.SupplierBtn);
            this.panel3.Controls.Add(this.CategoryBtn);
            this.panel3.Controls.Add(this.ItemBtn);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.CustomerBtn);
            this.panel3.Controls.Add(this.EmployeeBtn);
            this.panel3.Controls.Add(this.DashboardBtn);
            this.panel3.Location = new System.Drawing.Point(356, 37);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(979, 32);
            this.panel3.TabIndex = 58;
            // 
            // SupplierBtn
            // 
            this.SupplierBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.SupplierBtn.FlatAppearance.BorderSize = 0;
            this.SupplierBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SupplierBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.SupplierBtn.Image = ((System.Drawing.Image)(resources.GetObject("SupplierBtn.Image")));
            this.SupplierBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.SupplierBtn.Location = new System.Drawing.Point(794, 0);
            this.SupplierBtn.Name = "SupplierBtn";
            this.SupplierBtn.Size = new System.Drawing.Size(161, 32);
            this.SupplierBtn.TabIndex = 34;
            this.SupplierBtn.Text = "Supplier       ";
            this.SupplierBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.SupplierBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SupplierBtn.UseVisualStyleBackColor = true;
            this.SupplierBtn.Click += new System.EventHandler(this.SupplierBtn_Click);
            // 
            // CategoryBtn
            // 
            this.CategoryBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.CategoryBtn.FlatAppearance.BorderSize = 0;
            this.CategoryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CategoryBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CategoryBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CategoryBtn.Image = ((System.Drawing.Image)(resources.GetObject("CategoryBtn.Image")));
            this.CategoryBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CategoryBtn.Location = new System.Drawing.Point(688, 0);
            this.CategoryBtn.Name = "CategoryBtn";
            this.CategoryBtn.Size = new System.Drawing.Size(106, 32);
            this.CategoryBtn.TabIndex = 34;
            this.CategoryBtn.Text = " Category";
            this.CategoryBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.CategoryBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CategoryBtn.UseVisualStyleBackColor = true;
            this.CategoryBtn.Click += new System.EventHandler(this.CategoryBtn_Click);
            // 
            // ItemBtn
            // 
            this.ItemBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.ItemBtn.FlatAppearance.BorderSize = 0;
            this.ItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ItemBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.ItemBtn.Image = ((System.Drawing.Image)(resources.GetObject("ItemBtn.Image")));
            this.ItemBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.ItemBtn.Location = new System.Drawing.Point(561, 0);
            this.ItemBtn.Name = "ItemBtn";
            this.ItemBtn.Size = new System.Drawing.Size(127, 32);
            this.ItemBtn.TabIndex = 34;
            this.ItemBtn.Text = " Items       ";
            this.ItemBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.ItemBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ItemBtn.UseVisualStyleBackColor = true;
            this.ItemBtn.Click += new System.EventHandler(this.ItemBtn_Click);
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Left;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.Location = new System.Drawing.Point(434, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 32);
            this.button1.TabIndex = 34;
            this.button1.Text = " Order       ";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.CustomerBtn.FlatAppearance.BorderSize = 0;
            this.CustomerBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CustomerBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.CustomerBtn.Image = ((System.Drawing.Image)(resources.GetObject("CustomerBtn.Image")));
            this.CustomerBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.CustomerBtn.Location = new System.Drawing.Point(294, 0);
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(140, 32);
            this.CustomerBtn.TabIndex = 34;
            this.CustomerBtn.Text = " Customer    ";
            this.CustomerBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.CustomerBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CustomerBtn.UseVisualStyleBackColor = true;
            this.CustomerBtn.Click += new System.EventHandler(this.CustomerBtn_Click);
            // 
            // EmployeeBtn
            // 
            this.EmployeeBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.EmployeeBtn.FlatAppearance.BorderSize = 0;
            this.EmployeeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EmployeeBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.EmployeeBtn.Image = ((System.Drawing.Image)(resources.GetObject("EmployeeBtn.Image")));
            this.EmployeeBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.EmployeeBtn.Location = new System.Drawing.Point(147, 0);
            this.EmployeeBtn.Name = "EmployeeBtn";
            this.EmployeeBtn.Size = new System.Drawing.Size(147, 32);
            this.EmployeeBtn.TabIndex = 34;
            this.EmployeeBtn.Text = " Employee";
            this.EmployeeBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.EmployeeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.EmployeeBtn.UseVisualStyleBackColor = true;
            this.EmployeeBtn.Click += new System.EventHandler(this.EmployeeBtn_Click);
            // 
            // DashboardBtn
            // 
            this.DashboardBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.DashboardBtn.FlatAppearance.BorderSize = 0;
            this.DashboardBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DashboardBtn.Font = new System.Drawing.Font("Nirmala UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DashboardBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.DashboardBtn.Image = ((System.Drawing.Image)(resources.GetObject("DashboardBtn.Image")));
            this.DashboardBtn.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.DashboardBtn.Location = new System.Drawing.Point(0, 0);
            this.DashboardBtn.Name = "DashboardBtn";
            this.DashboardBtn.Size = new System.Drawing.Size(147, 32);
            this.DashboardBtn.TabIndex = 34;
            this.DashboardBtn.Text = " Dashboard";
            this.DashboardBtn.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.DashboardBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.DashboardBtn.UseVisualStyleBackColor = true;
            this.DashboardBtn.Click += new System.EventHandler(this.DashboardBtn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SlateGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1330, 28);
            this.panel2.TabIndex = 69;
            // 
            // PerchaceMethod
            // 
            this.PerchaceMethod.Location = new System.Drawing.Point(77, 275);
            this.PerchaceMethod.Multiline = true;
            this.PerchaceMethod.Name = "PerchaceMethod";
            this.PerchaceMethod.Size = new System.Drawing.Size(215, 34);
            this.PerchaceMethod.TabIndex = 72;
            // 
            // orders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(56)))), ((int)(((byte)(79)))));
            this.ClientSize = new System.Drawing.Size(1330, 718);
            this.Controls.Add(this.PerchaceMethod);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.TotalPri);
            this.Controls.Add(this.ItemPrice);
            this.Controls.Add(this.Quantity);
            this.Controls.Add(this.BillDGV);
            this.Controls.Add(this.ItemName);
            this.Controls.Add(this.CustomerID);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ItemId);
            this.Controls.Add(this.OrderDate);
            this.Controls.Add(this.BillBtn);
            this.Controls.Add(this.OrderBtn);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OrderDGV);
            this.Controls.Add(this.Amount);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "orders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "orders";
            this.Load += new System.EventHandler(this.orders_Load);
            ((System.ComponentModel.ISupportInitialize)(this.OrderDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillDGV)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView OrderDGV;
        private System.Windows.Forms.TextBox Amount;
        private System.Windows.Forms.Button BillBtn;
        private System.Windows.Forms.Button OrderBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.DateTimePicker OrderDate;
        private System.Windows.Forms.ComboBox ItemId;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox CustomerID;
        private System.Windows.Forms.TextBox ItemName;
        private System.Windows.Forms.DataGridView BillDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPrice;
        private System.Windows.Forms.TextBox Quantity;
        private System.Windows.Forms.TextBox ItemPrice;
        private System.Windows.Forms.Label TotalPri;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button SupplierBtn;
        private System.Windows.Forms.Button CategoryBtn;
        private System.Windows.Forms.Button ItemBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button CustomerBtn;
        private System.Windows.Forms.Button EmployeeBtn;
        private System.Windows.Forms.Button DashboardBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox PerchaceMethod;
    }
}