﻿using sales_management;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_management
{
    public partial class Create_account : Form
    {
        public Create_account()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        
        private void Create_account_Load(object sender, EventArgs e)
        {

        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            if (FirstName.Text == "" || LastName.Text == "" || UserName.Text == "" || Password.Text == "" || ConfirmPassword.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    string query = "INSERT INTO [Users] ([First Name],[Last Name],[User Name],[Password],[Confirm Password],[Email]) VALUES (@FirstName, @LastName, @Username, @Password,@ConfirmPassword,@Email)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", LastName.Text);
                        cmd.Parameters.AddWithValue("@Username", UserName.Text);
                        cmd.Parameters.AddWithValue("@Password", Password.Text);
                        cmd.Parameters.AddWithValue("@ConfirmPassword", ConfirmPassword.Text);
                        cmd.Parameters.AddWithValue("@Email", Email.Text);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Account created successfully!");
                        con.Close();
                    }

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
            CreateBtn.Height = CreateBtn.Height;
            CreateBtn.Top = CreateBtn.Top;
            CreateBtn.BackColor = Color.FromArgb(46, 51, 73);

            FirstName.Clear();
            LastName.Clear();
            UserName.Clear();
            Password.Clear();
            ConfirmPassword.Clear();
            Email.Clear();
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

       
    }
    
}
