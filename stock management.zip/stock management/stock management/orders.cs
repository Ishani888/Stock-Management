﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Security.AccessControl;
using System.Text.RegularExpressions;

namespace sales_management
{
    public partial class orders : Form
    {
        public orders()
        {
            InitializeComponent();
            GetCustomer();
            GetItem();
            ShowOrder();
        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void ShowOrder()
        {
            con.Open();
            string Query = "SELECT * from [Order]";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            OrderDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        private void GetCustomer()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * from Customer", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("[Customer Id]", typeof(int));
            dt.Load(Rdr);
            CustomerID.ValueMember = "Customer Id";
            CustomerID.DataSource = dt;

            con.Close();

        }
        private void GetItem()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Items]", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("[Item No]", typeof(int));
            dt.Load(Rdr);
            ItemId.ValueMember = "Item No";
            ItemId.DataSource = dt;

            con.Close();

        }

        private void GetItemName()
        {
            con.Open();
            string mysql = "SELECT * FROM Items WHERE [Item No]='" + ItemId.SelectedValue.ToString() + "'";
            SqlCommand cmd = new SqlCommand(mysql, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows) {
                ItemName.Text = dr["Name"].ToString();
                ItemPrice.Text = dr["Price"].ToString();
            }

            con.Close();

        }



        private void ItemId_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetItemName();
        }
        int n = 0;
        int GTotal = 0;
        private void BillBtn_Click(object sender, EventArgs e)
        {
            if (ItemName.Text == "" || Quantity.Text == "")
            {
                MessageBox.Show("Missing Information!!!");
            }
            else {
                int total = Convert.ToInt32(Quantity.Text) * Convert.ToInt32(ItemPrice.Text);
                DataGridViewRow newrow = new DataGridViewRow();
                newrow.CreateCells(BillDGV);
                newrow.Cells[0].Value = n + 1;
                newrow.Cells[1].Value = ItemName.Text;
                newrow.Cells[2].Value = ItemPrice.Text;
                newrow.Cells[3].Value = Quantity.Text;
                newrow.Cells[4].Value = total;
                BillDGV.Rows.Add(newrow);
                GTotal = GTotal + total;
                TotalPri.Text = "Rs." + GTotal;
                Amount.Text = "" + GTotal;

                n++;
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT [Quentity] FROM [Items] WHERE [Item No] = @ItemId", con);
                    cmd.Parameters.AddWithValue("@ItemId", ItemId.SelectedValue.ToString());
                    int currentQuantity = Convert.ToInt32(cmd.ExecuteScalar());

                    if (currentQuantity < Convert.ToInt32(Quantity.Text))
                    {
                        MessageBox.Show("Insufficient stock!");
                    }
                    else
                    {
                        cmd = new SqlCommand("UPDATE [Items] SET [Quentity] = @NewQuantity WHERE [Item No] = @ItemId", con);
                        cmd.Parameters.AddWithValue("@NewQuantity", currentQuantity - Convert.ToInt32(Quantity.Text));
                        cmd.Parameters.AddWithValue("@ItemId", ItemId.SelectedValue.ToString());
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }


            }
        }
        //Insert Order Details                    
        private void OrderBtn_Click(object sender, EventArgs e)
        {
            if (CustomerID.SelectedIndex == -1 || Amount.Text == ""|| PerchaceMethod.Text=="")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into [Order] values (@CustoID,@OrderDate,@Amount,@PerchaseMethode)", con);
                    cmd.Parameters.AddWithValue("@CustoID", CustomerID.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@OrderDate", OrderDate.Value.Date);
                    cmd.Parameters.AddWithValue("@Amount", Amount.Text);
                    cmd.Parameters.AddWithValue("@PerchaseMethode", PerchaceMethod.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Order saved!!!");
                   

                    con.Close();
                    ShowOrder();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CustomerID_Enter(object sender, EventArgs e)
        {
            if (CustomerID.Text == "Customer ID")
            {
                CustomerID.Text = "";
                CustomerID.ForeColor = Color.Black;
            }
        }

        private void CustomerID_Leave(object sender, EventArgs e)
        {
            if(CustomerID.Text == "")
            {
                CustomerID.Text = "Amount";
                CustomerID.ForeColor = Color.LightGray;
            }
        }

        private void Amount_Enter(object sender, EventArgs e)
        {
            if (Amount.Text == "Amount")
            {
                Amount.Text = "";
                Amount.ForeColor = Color.Black;
            }
        }

        private void Amount_Leave(object sender, EventArgs e)
        {
            if (Amount.Text == "")
            {
                Amount.Text = "Amount";
                Amount.ForeColor = Color.LightGray;
            }
        }

        private void ItemId_Enter(object sender, EventArgs e)
        {
            if (ItemId.Text == "Item ID")
            {
                ItemId.Text = "";
                ItemId.ForeColor = Color.Black;
            }
        }

        private void ItemId_Leave(object sender, EventArgs e)
        {
            if (ItemId.Text == "")
            {
                ItemId.Text = "Item ID";
                ItemId.ForeColor = Color.LightGray;
            }
        }

        private void ItemName_Enter(object sender, EventArgs e)
        {
            if (ItemName.Text == "Item Name")
            {
                ItemName.Text = "";
                ItemName.ForeColor = Color.Black;
            }
        }

        private void ItemName_Leave(object sender, EventArgs e)
        {
            if (ItemName.Text == "")
            {
                ItemName.Text = "Item Name";
                ItemName.ForeColor = Color.LightGray;
            }
        }

        private void ItemPrice_Enter(object sender, EventArgs e)
        {
            if (ItemPrice.Text == "Item Price")
            {
                ItemPrice.Text = "";
                ItemPrice.ForeColor = Color.Black;
            }
        }

        private void ItemPrice_Leave(object sender, EventArgs e)
        {
            if (CustomerID.Text == "")
            {
                CustomerID.Text = "Item Price";
                CustomerID.ForeColor = Color.LightGray;
            }
        }

        private void Quantity_Enter(object sender, EventArgs e)
        {
            if (Quantity.Text == "Quantity")
            {
                Quantity.Text = "";
                Quantity.ForeColor = Color.Black;
            }
        }

        private void Quantity_Leave(object sender, EventArgs e)
        {
            if (Quantity.Text == "")
            {
                Quantity.Text = "Quantity";
                Quantity.ForeColor = Color.LightGray;
            }
        }

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }
        int key = 0;
        private void CancelBtn_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Key: " + key); 

            if (key == 0)
            {
                MessageBox.Show(this, "Select the Order!!!");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  [Order] WHERE [Order No]=@Key", con);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Order Deleted!!!");
                    con.Close();
                    ShowOrder();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void OrderDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.OrderDGV.Rows[e.RowIndex];
                CustomerID.Text = row.Cells[1].Value.ToString();
                OrderDate.Text = row.Cells[2].Value.ToString();
                Amount.Text = row.Cells[3].Value.ToString();
                PerchaceMethod.Text = row.Cells[4].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }
        //create billing process
        private void BillDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.BillDGV.Rows[e.RowIndex];
                ItemId.Text = row.Cells[1].Value.ToString();
                ItemName.Text = row.Cells[2].Value.ToString();
                ItemPrice.Text = row.Cells[3].Value.ToString();
                Quantity.Text = row.Cells[4].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void orders_Load(object sender, EventArgs e)
        {
            OrderDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);
        }

        
    }
}
