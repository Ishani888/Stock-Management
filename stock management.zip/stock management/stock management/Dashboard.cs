﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using sales_management;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Windows.Forms.DataVisualization.Charting;

namespace sales_management
{
    public partial class Dashboard : Form
    {


        private string username;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]


        private static extern IntPtr CreateRoundRectRgn
         (
              int nLeftRect,
              int nTopRect,
              int nRightRect,
              int nBottomRect,
              int nWidthEllipse,
             int nHeightEllipse

          );

        public Dashboard()
        {
            InitializeComponent();
            CountCategories();
            CountSuppliers();
            CountCustomer();
            MaximumOrder();
            GetLatestDate();
            DisplayCustomer();
            GetBestCustmer();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            pnlNav.Height = DashboardBtn.Height;
            pnlNav.Top = DashboardBtn.Top;
            pnlNav.Left = DashboardBtn.Left;
            DashboardBtn.BackColor = Color.FromArgb(46, 51, 73);
            DisplayDataOnChart();
            this.username = Login.username;
        }

        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void CountCategories()
        {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT count(*) from category", con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            CategoryCount.Text = dt.Rows[0][0].ToString() + "  Categories";
            con.Close();
        }
        int CustoCount = 0;
        private void GetBestCustmer()
        {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT Name from Customer join [Order] on Customer.[Customer Id]=[Order].CustomerId where [Order].Amount=(SELECT Max(Amount) from [Order])", con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            BestCustomer.Text = dt.Rows[0][0].ToString();
            con.Close();
        }
        private void CountSuppliers()
        {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT count(*) from Supplier", con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            SupplierCount.Text = dt.Rows[0][0].ToString() + "  Suppliers";
            con.Close();
        }
        private void CountCustomer()
        {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT count(*) from Customer", con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            CustomerCount.Text = dt.Rows[0][0].ToString() + "  Customers";
            CustoCount = Convert.ToInt32(dt.Rows[0][0].ToString());
            con.Close();
        }
        private void MaximumOrder()
        {
            con.Open();
            SqlDataAdapter sad = new SqlDataAdapter("SELECT Max(Amount) from [Order]", con);
            DataTable dt = new DataTable();
            sad.Fill(dt);
            MaxOrder.Text = "Rs . " + dt.Rows[0][0].ToString();
            con.Close();
        }
        private void GetLatestDate()
        {
            try
            {
                con.Open();
                SqlDataAdapter sad = new SqlDataAdapter("SELECT Max(Date) from [Order]", con);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                LatestOrder.Text = dt.Rows[0][0].ToString();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        List<string> Customers = new List<string>();
        List<double> CustomerPurchase = new List<double>();

        public void GetCustomerData()
        {
            try
            {
                con.Open();
                string query = "SELECT Customer.[Customer Id], Name, Amount FROM Customer JOIN [Order] ON Customer.[Customer Id] = [Order].[CustomerId]";
                SqlCommand cmd = new SqlCommand(query, con);
                DataTable dt = new DataTable();
                SqlDataAdapter sad = new SqlDataAdapter(cmd);
                sad.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {
                    string customerName = dr["Name"].ToString();
                    double amount = Convert.ToDouble(dr["Amount"]);

                    // Check if the customer already exists in the list
                    int index = Customers.IndexOf(dr["Customer Id"].ToString());

                    if (index == -1)
                    {
                        // If the customer does not exist, add a new entry
                        Customers.Add(dr["Customer Id"].ToString());
                        CustomerPurchase.Add(amount);
                    }
                    else
                    {
                        // If the customer exists, update the purchase amount
                        CustomerPurchase[index] += amount;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        private void DisplayDataOnChart()
        {
            chart1.Series.Clear();

            // Add a new series to the chart
            var series = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "Customer Purchase",
                Color = System.Drawing.Color.CornflowerBlue,
                IsVisibleInLegend = true,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column
            };

            // Add data to the series
            for (int i = 0; i < Customers.Count; i++)
            {
                series.Points.AddXY(Customers[i], CustomerPurchase[i]);
            }

            // Add the series to the chart
            chart1.Series.Add(series);

            // Set axis labels
            chart1.ChartAreas[0].AxisX.Title = "Customer Id";
            chart1.ChartAreas[0].AxisY.Title = "Purchase Amount";
            chart1.ChartAreas[0].AxisY.TitleForeColor = System.Drawing.Color.Yellow;
            chart1.ChartAreas[0].AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft YaHei", 10);
            // Refresh the chart
            chart1.Invalidate();
        }
    
    public void DisplayCustomer() {

            GetCustomerData();
       
        }
        private DataTable GetSalesData()
        {
            DataTable dataTable = new DataTable();

                con.Open();

            // Replace this query with your actual query
            string query = "SELECT Name, Quentity FROM Items";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }


            return dataTable;
        }
        private void LoadSalesData()
        {
            DataTable salesData = GetSalesData();

            // Bind data to the chart
            chart2.Series.Clear();
            chart2.Series.Add("Sales");

            // Calculate total quantity
            int totalQuantity = salesData.AsEnumerable().Sum(row => row.Field<int>("Quentity"));

            foreach (DataRow row in salesData.Rows)
            {
                string itemName = row.Field<string>("Name");
                int quantity = row.Field<int>("Quentity");

                // Calculate percentage
                int percentage = (int)Math.Round((quantity / (double)totalQuantity) * 100);

                // Add data point to the chart
                DataPoint dataPoint = new DataPoint();
                dataPoint.Label = $"{itemName} ({percentage}%)"; 
                dataPoint.YValues = new double[] { percentage };
                chart2.Series["Sales"].Points.Add(dataPoint);
            }

            // Set chart type to Pie
            chart2.Series["Sales"].ChartType = SeriesChartType.Pie;

            // Set legend
            chart2.Legends.Add("Legend");
            chart2.Legends["Legend"].Docking = Docking.Right;

            // Set title
            Title title = new Title();
            title.Name = "SalesData";
            title.Text = "Sales Data";
            title.ForeColor = System.Drawing.Color.Yellow;
            chart2.Titles.Add(title);
        }
        private void Dashboard_Load(object sender, EventArgs e)
        {
            LoadSalesData();
            if (username == "Admin")
            {
                CreateAccount.Visible = true;
            }
            else
            {
                CreateAccount.Visible = false;
            }
        }

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = DashboardBtn.Height;
            pnlNav.Top = DashboardBtn.Top;
            pnlNav.Left = DashboardBtn.Left;
            DashboardBtn.BackColor = Color.FromArgb(46, 51, 73);
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = EmployeeBtn.Height;
            pnlNav.Top = EmployeeBtn.Top;
            EmployeeBtn.BackColor = Color.FromArgb(46, 51, 73);
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = CustomerBtn.Height;
            pnlNav.Top = CustomerBtn.Top;
            CustomerBtn.BackColor = Color.FromArgb(46, 51, 73);
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = OrderBtn.Height;
            pnlNav.Top = OrderBtn.Top;
            OrderBtn.BackColor = Color.FromArgb(46, 51, 73);
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = ItemBtn.Height;
            pnlNav.Top = ItemBtn.Top;
            ItemBtn.BackColor = Color.FromArgb(46, 51, 73);
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = CategoryBtn.Height;
            pnlNav.Top = CategoryBtn.Top;
            CategoryBtn.BackColor = Color.FromArgb(46, 51, 73);
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            pnlNav.Height = SupplierBtn.Height;
            pnlNav.Top = SupplierBtn.Top;
            SupplierBtn.BackColor = Color.FromArgb(46, 51, 73);
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void DashboardBtn_Leave(object sender, EventArgs e)
        {
            DashboardBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void EmployeeBtn_Leave(object sender, EventArgs e)
        {
            EmployeeBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void CustomerBtn_Leave(object sender, EventArgs e)
        {
            CustomerBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void OrderBtn_Leave(object sender, EventArgs e)
        {
            OrderBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void ItemBtn_Leave(object sender, EventArgs e)
        {
            ItemBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void CategoryBtn_Leave(object sender, EventArgs e)
        {
            CategoryBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void SupplierBtn_Leave(object sender, EventArgs e)
        {
            SupplierBtn.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void CreateAccount_Click(object sender, EventArgs e)
        {
            Create_account obj = new Create_account();
            obj.Show();
            this.Hide();
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
