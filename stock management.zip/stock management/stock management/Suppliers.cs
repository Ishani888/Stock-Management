﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_management
{
    public partial class Suppliers : Form
    {
        public Suppliers()
        {
            InitializeComponent();
            ShowSupplier();
        }
        private void ShowSupplier()
        {
            con.Open();
            string Query = "SELECT * from Supplier";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            SuppliersDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        private void Suppliers_Load(object sender, EventArgs e)
        {
            SuppliersDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);


        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }
        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void SupName_Enter(object sender, EventArgs e)
        {
            if (SupName.Text == "Supplier Name")
            {
                SupName.Text = "";
                SupName.ForeColor = Color.Black;
            }
        }

        private void SupName_Leave(object sender, EventArgs e)
        {
            if (SupName.Text == "")
            {
                SupName.Text = "Supplier Name";
                SupName.ForeColor = Color.LightGray;
            }
        }

        private void ConNo_Enter(object sender, EventArgs e)
        {
            if (ConNo.Text == "Contact No")
            {
                ConNo.Text = "";
                ConNo.ForeColor = Color.Black;
            }
        }

        private void ConNo_Leave(object sender, EventArgs e)
        {
            if (ConNo.Text == "")
            {
                ConNo.Text = "Contact No";
                ConNo.ForeColor = Color.LightGray;
            }
        }

        private void AddressTxt_Enter(object sender, EventArgs e)
        {
            if (AddressTxt.Text == "Address")
            {
                AddressTxt.Text = "";
                AddressTxt.ForeColor = Color.Black;
            }
        }

        private void AddressTxt_Leave(object sender, EventArgs e)
        {
            if (AddressTxt.Text == "")
            {
                AddressTxt.Text = "Address";
                AddressTxt.ForeColor = Color.LightGray;
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (SupName.Text == "" || ConNo.Text == "" || AddressTxt.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into Supplier values (@SupName,@ContactNo,@Address)", con);
                    cmd.Parameters.AddWithValue("@SupName", SupName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ConNo.Text);
                    cmd.Parameters.AddWithValue("@Address", AddressTxt.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Supplier saved!!!");
                    con.Close();
                    ShowSupplier();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (SupName.Text == "" || ConNo.Text == "" || AddressTxt.Text == "")
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE  Supplier set  Name=@SupName,[Contact No]=@ContactNo,Address=@Address WHERE [Supplier Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@SupName", SupName.Text);
                    cmd.Parameters.AddWithValue("@ContactNo", ConNo.Text);
                    cmd.Parameters.AddWithValue("@Address", AddressTxt.Text);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Supplier Update!!!");
                    con.Close();
                    ShowSupplier();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int key = 0;
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show(this, "Select the Supplier!!!");
            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  Supplier WHERE [Supplier Id]=@Key", con);
                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Supplier Deleted!!!");
                    con.Close();
                    ShowSupplier();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void SuppliersDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.SuppliersDGV.Rows[e.RowIndex];
                SupName.Text = row.Cells[1].Value.ToString();
                ConNo.Text = row.Cells[2].Value.ToString();
                AddressTxt.Text = row.Cells[3].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
