﻿using sales_management;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace sales_management
{
    public partial class Login : Form

    {
        public static string username;
        public static string loggedInUsername;
        public Login(Dashboard dashboardForm)
        {
            InitializeComponent();
      
        }


        public Login()
        {
            InitializeComponent();
        }

        private void UserName_Enter(object sender, EventArgs e)
        {
            if (UserName.Text == "User")
            {
                UserName.Text = "";
                UserName.ForeColor = Color.Black;
            }
        }

        private void UserName_Leave(object sender, EventArgs e)
        {
            if (UserName.Text == "")
            {
                UserName.Text = "User";
                UserName.ForeColor = Color.LightGray;
            }
        }

        private void password_Enter(object sender, EventArgs e)
        {
            if (UserName.Text == "Password")
            {
                UserName.Text = " ";
                UserName.ForeColor = Color.Black;

            }
        }

        private void password_Leave(object sender, EventArgs e)
        {
            if (UserName.Text == " ")
            {
                UserName.Text = "Password";
                UserName.ForeColor = Color.LightGray;
            }
        }
        
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=USER\\SQLEXPRESS;Initial Catalog=\"Dinapala sales management system\";Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                username = UserName.Text;
                string password = Password.Text;

                string query = "SELECT COUNT(*) FROM Users WHERE [User Name]=@username AND password=@password";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);

               int count = (int)command.ExecuteScalar();

                if (count == 1)
                {
                    Dashboard dashboard = new Dashboard();
                    dashboard.Show();
                    this.Hide();
                }

                else if (username == "Admin" && password == "Admin123")
                {
                    Dashboard dashboard = new Dashboard();
                    dashboard.Show();
                    this.Hide();
                }

                else if (UserName.Text == "" || Password.Text == "")
                {
                    MessageBox.Show(" Empty username or password.");
                }
                else {
                    MessageBox.Show("Invalied usaname and password.");
                }
                
            }
        }

        
    }
}



    

