﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sales_management
{
    public partial class Sale_items : Form
    {
        public Sale_items()
        {
            InitializeComponent();
            ShowItem();
            GetCategory();
            GetSupplier();
        }
        private void ShowItem()
        {
            con.Open();
            string Query = "SELECT * from [Items]";
            SqlDataAdapter sad = new SqlDataAdapter(Query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sad);
            var ds = new DataSet();
            sad.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            con.Close();

        }
        private void Sale_items_Load(object sender, EventArgs e)
        {
            
            ItemDGV.ColumnHeadersDefaultCellStyle.Font = new Font("Microsoft MHei", 10, FontStyle.Bold);
        }
        SqlConnection con = new SqlConnection(@"Data Source=USER\SQLEXPRESS;Initial Catalog=""Dinapala sales management system"";Integrated Security=True");
        private void GetCategory()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Category]", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("[Category Id]", typeof(int));
            dt.Load(Rdr);
            CatCb.ValueMember = "Category Id";
            CatCb.DataSource = dt;
            con.Close();

        }
        private void GetSupplier()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Supplier]", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("[Supplier Id]", typeof(int));
            dt.Load(Rdr);
            SupplierId.ValueMember = "Supplier Id";
            SupplierId.DataSource = dt;
            con.Close();

        }

        private void CatCb_Enter(object sender, EventArgs e)
        {
            if (QuentityValue.Text == "Category")
            {
                QuentityValue.Text = "";
                QuentityValue.ForeColor = Color.Black;
            }
        }

        private void CatCb_Leave(object sender, EventArgs e)
        {
            if (CatCb.Text == "")
            {
                CatCb.Text = "Category";
                CatCb.ForeColor = Color.LightGray;
            }
        }



        private void SupplierId_Enter(object sender, EventArgs e)
        {
            if (SupplierId.Text == "Supplier Id")
            {
                SupplierId.Text = "";
                SupplierId.ForeColor = Color.Black;
            }
        }

        private void SupplierId_Leave(object sender, EventArgs e)
        {
            if (SupplierId.Text == "")
            {
                SupplierId.Text = "Supplier Id";
                SupplierId.ForeColor = Color.LightGray;
            }
        }

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void EmployeeBtn_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.Show();
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            Customer obj = new Customer();
            obj.Show();
            this.Hide();
        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            orders obj = new orders();
            obj.Show();
            this.Hide();
        }

        private void ItemBtn_Click(object sender, EventArgs e)
        {
            Sale_items obj = new Sale_items();
            obj.Show();
            this.Hide();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Category obj = new Category();
            obj.Show();
            this.Hide();
        }

        private void SupplierBtn_Click(object sender, EventArgs e)
        {
            Suppliers obj = new Suppliers();
            obj.Show();
            this.Hide();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (ItemName.Text == ""  || CatCb.SelectedIndex == -1 || QuentityValue.Text == ""|| ItemPrice.Text == "" || SupplierId.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {
                    con.Open();

                    // Check if an item with the same name already exists
                    SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM [Items] WHERE [Name] = @IName", con);
                    checkCmd.Parameters.AddWithValue("@IName", ItemName.Text);
                    int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                    if (count > 0)
                    {
                        // Item with the same name already exists, update its quantity
                        SqlCommand updateCmd = new SqlCommand("UPDATE [Items] SET [Quentity] = [Quentity] + @Quentity WHERE [Name] = @IName", con);
                        updateCmd.Parameters.AddWithValue("@IName", ItemName.Text);
                        updateCmd.Parameters.AddWithValue("@Quentity", Convert.ToInt32(QuentityValue.Text));
                        updateCmd.ExecuteNonQuery();
                    }
                    else
                    {
                        // Item with this name doesn't exist, insert a new record
                        SqlCommand Cmd = new SqlCommand("INSERT into [Items] values (@IName,@Category,@Quentity,@Price,@SupplierId)", con);
                        Cmd.Parameters.AddWithValue("@IName", ItemName.Text);
                        
                        Cmd.Parameters.AddWithValue("@Category", CatCb.SelectedValue.ToString());
                        Cmd.Parameters.AddWithValue("@Quentity", QuentityValue.Text);
                        Cmd.Parameters.AddWithValue("@Price", ItemPrice.Text);
                        Cmd.Parameters.AddWithValue("@SupplierId", SupplierId.SelectedValue.ToString());
                        Cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show(this, "Item saved!!!");

                    con.Close();
                    ShowItem();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (ItemName.Text == "" ||  CatCb.SelectedIndex == -1 || QuentityValue.Text == "" || ItemPrice.Text == "" || SupplierId.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Data");

            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE  [Items] SET  Name=@IName,Category=@Category,Quentity=@Quentity,Price=@Price,[Supplier Id]=@SupplierId WHERE [Item No]=@IKey", con);
                    cmd.Parameters.AddWithValue("@IName", ItemName.Text);
                 
                    cmd.Parameters.AddWithValue("@Category", CatCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@Quentity", QuentityValue.Text);
                    cmd.Parameters.AddWithValue("@Price", ItemPrice.Text);
                    cmd.Parameters.AddWithValue("@SupplierId", SupplierId.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@IKey", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Item Update!!!");
                    con.Close();
                    ShowItem();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show(this, "Select the Item!!!");
            }
            else
            {
                try
                {

                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE  [Items] WHERE [Item No]=@Key", con);

                    cmd.Parameters.AddWithValue("@Key", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(this, "Item Deleted!!!");
                    con.Close();
                    ShowItem();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int key = 0;

        private void ItemPrice_Enter(object sender, EventArgs e)
        {

                if (ItemPrice.Text == "Item Price")
                {
                    ItemPrice.Text = "";
                    ItemPrice.ForeColor = Color.Black;
                }

        }

        private void ItemPrice_Leave(object sender, EventArgs e)
        {
        if (ItemPrice.Text == "")
        {
            ItemPrice.Text = "Item Price";
            ItemPrice.ForeColor = Color.LightGray;
        }
    }

        private void ItemName_Enter(object sender, EventArgs e)
        {
            if (ItemName.Text == "Item Name")
            {
                ItemName.Text = "";
                ItemName.ForeColor = Color.Black;
            }
        }

        private void ItemName_Leave(object sender, EventArgs e)
        {
            if (ItemName.Text == "")
            {
                ItemName.Text = "Item Name";
                ItemName.ForeColor = Color.LightGray;
            }
        }

        private void Quentity_Enter(object sender, EventArgs e)
        {
            if (QuentityValue.Text == "Quentity")
            {
                QuentityValue.Text = "";
                QuentityValue.ForeColor = Color.Black;
            }
        }

        private void Quentity_Leave(object sender, EventArgs e)
        {
            if (QuentityValue.Text == "")
            {
                QuentityValue.Text = "Quentity";
                QuentityValue.ForeColor = Color.LightGray;
            }
        }

        private void ItemDGV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.ItemDGV.Rows[e.RowIndex];
                ItemName.Text = row.Cells[1].Value.ToString();
             
                CatCb.Text = row.Cells[2].Value.ToString();
                QuentityValue.Text = row.Cells[3].Value.ToString();
                ItemPrice.Text = row.Cells[4].Value.ToString();
                SupplierId.Text = row.Cells[5].Value.ToString();
                key = Convert.ToInt32(row.Cells[0].Value);
            }
        }

        private void Quentity_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
